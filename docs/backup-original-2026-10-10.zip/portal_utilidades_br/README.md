# Utiliza BR — MVP com 12 ferramentas

Site estático, gratuito e responsivo. **Não está publicado** e **não tem monetização ativada**. Nenhum cadastro ou servidor é necessário para as ferramentas.

## Executar localmente

Na pasta do projeto:

```bash
python -m http.server 8000
```

Abra http://localhost:8000 . Para testar em outro dispositivo, publique os arquivos em um serviço HTTPS estático (por exemplo, GitHub Pages ou Cloudflare Pages) e teste no celular.

## Publicar

Envie `index.html`, `style.css` e `app.js` para um repositório e configure uma hospedagem estática apontando para a raiz do projeto. Use o endereço HTTPS publicado no QR Code. Não use `localhost` no QR Code para passageiros.

## Ferramentas

Porcentagem, desconto, juros compostos, parcelas Price, combustível, idade, dias entre datas, IMC adulto, contador de palavras, conversor de caixa de texto, gerador de senha, conversor de comprimento.

## Próximos passos

1. Testar com passageiros, medir quais ferramentas interessam.
2. Configurar domínio, analytics com consentimento conforme aplicável, Search Console e páginas específicas indexáveis por ferramenta.
3. Adicionar política de privacidade definitiva e dados do responsável antes de coletar dados ou habilitar anúncios.
4. Avaliar Google AdSense somente após atender aos requisitos de conteúdo, propriedade e políticas.
5. Criar ferramentas mais complexas apenas com validação técnica, legal e de demanda.

**Aviso:** Simulações não incluem tarifas, impostos, regras trabalhistas nem aconselhamento profissional. O IMC apresentado é somente para adultos. O site atual não garante volume de tráfego nem faturamento.
